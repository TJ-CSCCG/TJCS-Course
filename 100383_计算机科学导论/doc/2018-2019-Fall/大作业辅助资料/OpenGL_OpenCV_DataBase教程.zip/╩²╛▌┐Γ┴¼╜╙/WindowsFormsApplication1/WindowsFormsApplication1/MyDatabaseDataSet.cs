﻿namespace WindowsFormsApplication1
{


    public partial class MyDatabaseDataSet
    {
    }
}
namespace WindowsFormsApplication1 {
    
    
    public partial class MyDatabaseDataSet {
    }
}
