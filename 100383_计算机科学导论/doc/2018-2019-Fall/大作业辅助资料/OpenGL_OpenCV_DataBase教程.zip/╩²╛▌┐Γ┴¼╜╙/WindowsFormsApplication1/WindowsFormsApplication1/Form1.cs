﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //创建一个数据表
            DataTable dt = new DataTable();
            //创建一个数据库连接字符串
            String connectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=MyDataBase.mdb";
            //创建一个数据连接
            OleDbConnection connection = new OleDbConnection(connectionString);
            String SQL = textBox1.Text;
            try
            {
                //打开数据库连接
                connection.Open();
                //执行数据库查询
                OleDbDataAdapter oda = new OleDbDataAdapter(SQL, connection);
                //label1.Text = mydr[0].ToString();
                //将查询结果加入先前的数据库表
                oda.Fill(dt);
                //设置dataGridView的数据源
                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                connection.Close();
            }
        }
    }
}
