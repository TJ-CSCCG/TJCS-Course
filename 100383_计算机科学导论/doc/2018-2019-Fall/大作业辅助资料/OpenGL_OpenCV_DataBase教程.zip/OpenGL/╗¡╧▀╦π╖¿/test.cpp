#pragma once

#include"DrawCircle.h"
#include"DrawEllipse.h"
#include"DrawLine.h"
#include"SetPixel.h"

#include<iostream>

using	std::cout;
using	std::cin;

void	init()
{
	glClearColor(1.0, 1.0, 1.0, 0.0);
	glMatrixMode(GL_PROJECTION);
	gluOrtho2D(0, 400, 0, 300);
}

void	Line()
{
	glClear(GL_COLOR_BUFFER_BIT);

	glColor3f(0.0, 0.0, 1.0);
	int		Xstart = 0;
	int		Ystart = 0;
	int		Xend = 0;
	int		Yend = 0;
	cout << "please input start:\nx:";
	cin >> Xstart;
	cout << "y:";
	cin >> Ystart;
	cout << "please input end:\nx:";
	cin >> Xend;
	cout << "y:";
	cin >> Yend;
	Point	start(Xstart, Ystart);
	Point	end(Xend, Yend);
	LineBresenham(start,end);
	glFlush();
}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowPosition(100, 80);
	glutInitWindowSize(400, 300);
	glutCreateWindow("Algorithm of Shape");

	init();

	glutDisplayFunc(&Line);
	glutMainLoop();
}