#include"DrawLine.h"

void	LineDDA(const Point& start, const Point& end)
{
	int		dx = end.GetCoordX() - start.GetCoordX();
	int		dy = end.GetCoordY() - start.GetCoordY();
	int		steps;
	float	XIncrement, YIncrement;
	float	x = start.GetCoordX();
	float	y = start.GetCoordY();
	if (abs(dx) > abs(dy))
		steps = abs(dx);
	else
		steps = abs(dy);
	XIncrement = float(dx) / float(steps);
	YIncrement = float(dy) / float(steps);

	SetPixel(round(x), round(y));
	for (int k = 0; k != steps; k++)
	{
		x += XIncrement;
		y += YIncrement;
		SetPixel(round(x), round(y));
	}
}

//б�ʴ���0��С��1
void	Base_LineBresenham_1(const Point& start, const Point& end)
{
	int dx = abs(end.GetCoordX() - start.GetCoordX());
	int dy = abs(start.GetCoordY() - end.GetCoordY());
	int p = 2 * dy - dx;
	int twoDy = 2 * dy;
	int twoDyMinusDx = 2 * (dy - dx);
	int x, y;
	int End = end.GetCoordX();
	if (start.GetCoordX() > end.GetCoordX())
	{
		x = end.GetCoordX();
		y = end.GetCoordY();
		End = start.GetCoordX();
	}
	else
	{
		x = start.GetCoordX();
		y = start.GetCoordY();
	}
	SetPixel(x, y);
	while (x < End)
	{
		++x;
		if (p < 0)
			p += twoDy;
		else
		{
			y++;
			p += twoDyMinusDx;
		}
		SetPixel(x, y);
	}
}

//б�ʴ��ڵ���1
void	Base_LineBresenham_2(const Point& start, const Point& end)
{
	int dx = abs(end.GetCoordX() - start.GetCoordX());
	int dy = abs(start.GetCoordY() - end.GetCoordY());
	int p = 2 * dx - dy;
	int twoDx = 2 * dx;
	int twoDxMinusDy = 2 * (dx - dy);
	int x, y;
	int End = end.GetCoordY();
	if (start.GetCoordY() > end.GetCoordY())
	{
		x = end.GetCoordX();
		y = end.GetCoordY();
		End = start.GetCoordY();
	}
	else
	{
		x = start.GetCoordX();
		y = start.GetCoordY();
	}
	SetPixel(x, y);
	while (y < End)
	{
		++y;
		if (p < 0)
			p += twoDx;
		else
		{
			++x;
			p += twoDxMinusDy;
		}
		SetPixel(x, y);
	}
}

////б�ʴ���-1��С�ڵ���0
void	Base_LineBresenham_3(const Point& start, const Point& end)
{
	int dx = abs(end.GetCoordX() - start.GetCoordX());
	int dy = abs(start.GetCoordY() - end.GetCoordY());
	int p = 2 * dy - dx;
	int twoDy = 2 * dy;
	int twoDyMinusDx = 2 * (dy - dx);
	int x, y;
	int End = end.GetCoordX();
	if (start.GetCoordX() > end.GetCoordX())
	{
		x = end.GetCoordX();
		y = end.GetCoordY();
		End = start.GetCoordY();
	}
	else
	{
		x = start.GetCoordX();
		y = start.GetCoordY();
	}
	SetPixel(x, y);
	while (x < End)
	{
		++x;
		if (p < 0)
			p += twoDy;
		else
		{
			--y;
			p += twoDyMinusDx;
		}
		SetPixel(x, y);
	}
}

////б��С�ڵ���-1
void	Base_LineBresenham_4(const Point& start, const Point& end)
{
	int dx = abs(end.GetCoordX() - start.GetCoordX());
	int dy = abs(start.GetCoordY() - end.GetCoordY());
	int p = 2 * dx - dy;
	int twoDx = 2 * dx;
	int twoDxMinusDy = 2 * (dx - dy);
	int x, y;
	int End = end.GetCoordY();
	if (start.GetCoordY() > end.GetCoordY())
	{
		x = end.GetCoordX();
		y = end.GetCoordY();
		End = start.GetCoordY();
	}
	else
	{
		x = start.GetCoordX();
		y = start.GetCoordY();
	}
	SetPixel(x, y);
	while (y < End)
	{
		++y;
		if (p < 0)
			p += twoDx;
		else
		{
			x--;
			p += twoDxMinusDy;
		}
		SetPixel(x, y);
	}
}

void	LineBresenham(const Point& start, const Point& end)
{
	int		DX = end.GetCoordX() - start.GetCoordX();
	int		DY = end.GetCoordY() - start.GetCoordY();
	float	slope;
	if (DX != 0)
	{
		slope = float(DY) / float(DX);
	}
	else
		slope = INT_MAX;
	if (DY == 0)
	{
		if (start.GetCoordX() > end.GetCoordX())
		{
			for (int i = end.GetCoordX(); i <= start.GetCoordX(); ++i)
				SetPixel(i, start.GetCoordY());
		}
		else
			for (int i = start.GetCoordX(); i <= end.GetCoordX(); ++i)
				SetPixel(i, start.GetCoordY());
		return;
	}
	else if (DX == 0)
	{
		if (start.GetCoordY() > end.GetCoordY())
		{
			for (int i = end.GetCoordY(); i <= start.GetCoordY(); ++i)
				SetPixel(start.GetCoordX(), i);
		}
		else
			for (int i = start.GetCoordY(); i <= end.GetCoordY(); ++i)
				SetPixel(start.GetCoordX(), i);
		return;
	}
	else if (DX == DY)
	{
		if (DX > 0)
		{
			for (int i = start.GetCoordX(), j = start.GetCoordY(); i <= end.GetCoordX(); ++i, ++j)
				SetPixel(i, j);
		}
		else
			for (int i = end.GetCoordX(), j = end.GetCoordY(); i <= start.GetCoordX(); ++i, ++j)
				SetPixel(i, j);
		return;
	}
	else if (DX == -DY)
	{
		if (DX > 0)
		{
			for (int i = start.GetCoordX(), j = start.GetCoordY(); i <= end.GetCoordX(); ++i, --j)
				SetPixel(i, j);
		}
		else
			for (int i = end.GetCoordX(), j = end.GetCoordY(); i <= start.GetCoordX(); ++i, --j)
				SetPixel(i, j);
		return;
	}
	else if (slope > 1)
		/*Point	TransStart(start.GetCoordY(), end.GetCoordX());
		Point	TransEnd(end.GetCoordY(), end.GetCoordX());*/
		Base_LineBresenham_2(start, end);
	else if (slope < 1 && slope>0)
		Base_LineBresenham_1(start, end);
	else if (slope < -1)
		Base_LineBresenham_4(start, end);
	else
		Base_LineBresenham_3(start, end);
}