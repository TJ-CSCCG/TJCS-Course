#pragma once


#ifndef _SET_PIXEL_

#define	_SET_PIXEL_

#include<gl\glut.h>
#include<cstdio>

class Point
{
private:
	int		x;
	int		y;

public:
	Point()
	{
		x = 0;
		y = 0;
	}
	Point(int xx, int yy)
	{
		x = xx;
		y = yy;
	}

	int		GetCoordX()	const;
	int		GetCoordY()	const;

	void	IncreaseX()
	{
		++x;
	}
	void	IncreaseY()
	{
		++y;
	}
	void	DecreaseX()
	{
		--x;
	}
	void	DecreaseY()
	{
		--y;
	}

	void	SetCoord(int, int);

};

void		SetPixel(int x, int y);

void		SetPixel(const	Point& p);

inline	int	Point::GetCoordX()	const
{
	return	x;
}

inline	int	Point::GetCoordY()	const
{
	return	y;
}


inline	int	Round(const float a)
{
	return	int(a + 0.5);
}

#endif // !_SET_PIXEL_


