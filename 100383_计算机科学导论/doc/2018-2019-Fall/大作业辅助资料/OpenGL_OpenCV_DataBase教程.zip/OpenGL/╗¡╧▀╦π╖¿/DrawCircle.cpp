#include"DrawCircle.h"

void	SetCirclePoint(int xc, int yc, Point& p)
{
	SetPixel(xc + p.GetCoordX(), yc + p.GetCoordY());
	SetPixel(xc - p.GetCoordX(), yc + p.GetCoordY());
	SetPixel(xc + p.GetCoordX(), yc - p.GetCoordY());
	SetPixel(xc - p.GetCoordX(), yc - p.GetCoordY());
	SetPixel(xc + p.GetCoordY(), yc + p.GetCoordX());
	SetPixel(xc - p.GetCoordY(), yc + p.GetCoordX());
	SetPixel(xc + p.GetCoordY(), yc - p.GetCoordX());
	SetPixel(xc - p.GetCoordY(), yc - p.GetCoordX());
}

void	SetCirclePoint(Point& centre, Point& p)
{
	SetPixel(centre.GetCoordX() + p.GetCoordX(), centre.GetCoordY() + p.GetCoordY());
	SetPixel(centre.GetCoordX() - p.GetCoordX(), centre.GetCoordY() + p.GetCoordY());
	SetPixel(centre.GetCoordX() + p.GetCoordX(), centre.GetCoordY() - p.GetCoordY());
	SetPixel(centre.GetCoordX() - p.GetCoordX(), centre.GetCoordY() - p.GetCoordY());
	SetPixel(centre.GetCoordX() + p.GetCoordY(), centre.GetCoordY() + p.GetCoordX());
	SetPixel(centre.GetCoordX() - p.GetCoordY(), centre.GetCoordY() + p.GetCoordX());
	SetPixel(centre.GetCoordX() + p.GetCoordY(), centre.GetCoordY() - p.GetCoordX());
	SetPixel(centre.GetCoordX() - p.GetCoordY(), centre.GetCoordY() - p.GetCoordX());
}

void	DrawCircleMid(int centrex, int centrey, int radius)
{
	Point	CirclePoint(0, radius);
	SetCirclePoint(centrex,centrey,CirclePoint);
	int		p = 1 - radius;
	while (CirclePoint.GetCoordY() < CirclePoint.GetCoordY())
	{
		CirclePoint.IncreaseX();
		if (p < 0)
		{
			p += 2 * CirclePoint.GetCoordX() + 1;
		}
		else
		{
			CirclePoint.DecreaseY();
			p += 2 * (CirclePoint.GetCoordX() - CirclePoint.GetCoordY()) + 1;
		}
		SetCirclePoint(centrex, centrey, CirclePoint);
	}
}