#pragma once

#ifndef _DRAW_CIRCLE_

#define	_DRAW_CIRCLE_

#include"SetPixel.h"

void	DrawCircleMid(int centrex,int centrey,int radius);

void	SetCirclePoint(int x, int y,Point& p);

void	SetCirclePoint(Point& centre, Point& p);

#endif // !_DRAW_CIRCLE_
