#include"SetPixel.h"

void	Point::SetCoord(int	xx, int	yy)
{
	x = xx;
	y = yy;
}

void	SetPixel(int x, int y)
{
	glBegin(GL_POINTS);
		glVertex2i(x, y);
	glEnd();
}

void	SetPixel(const	Point& p)
{
	int	x = p.GetCoordX();
	int y = p.GetCoordY();
	glBegin(GL_POINTS);
		glVertex2i(x, y);
	glEnd();
}