#include"DrawEllipse.h"

void	EllipsePloytPoints(int xcentre, int ycentre, int x, int y)
{
	SetPixel(xcentre + x, ycentre + y);
	SetPixel(xcentre - x, ycentre + y);
	SetPixel(xcentre + x, ycentre - y);
	SetPixel(xcentre - x, ycentre - y);
}

void	DrawEllipseMidPoint(int xcentre, int ycentre, int Rx, int Ry)
{
	int		Rx_s = Rx*Rx;
	int		Ry_s = Ry*Ry;
	int		D_Rx_s = 2 * Rx_s;
	int		D_Ry_s = 2 * Ry_s;
	int		p = 0;
	int		x = 0;
	int		y = Ry;
	int		px = 0;
	int		py = D_Rx_s * y;

	p = Round(Ry_s - (Rx_s*Ry) + (0.25*Rx_s));
	while (px < py)
	{
		++x;
		px += D_Ry_s;
		if (p < 0)
			p += Ry_s + px;
		else
		{
			--y;
			py -= D_Rx_s;
			p += Ry_s + px - py;
		}
		EllipsePloytPoints(xcentre, ycentre, x, y);
	}
	
	p = Round(Ry_s*(x + 0.5)*(x + 0.5) + Rx_s*(y - 1)*(y - 1));
	while (y > 0)
	{
		--y;
		py -= D_Rx_s;
		if (p > 0)
			p += Rx_s - py;
		else
		{
			++x;
			px += D_Ry_s;
			p += Rx_s - py + px;
		}
		EllipsePloytPoints(xcentre, ycentre, x, y);
	}
}