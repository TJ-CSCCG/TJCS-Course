#pragma once

#ifndef _DRAW_ELLIPSE_

#define _DRAW_ELLIPSE_

#include"SetPixel.h"

void	DrawEllipseMidPoint(int xcentre, int ycentre, int rx, int ry);

#endif // !_DRAW_ELLIPSE_
