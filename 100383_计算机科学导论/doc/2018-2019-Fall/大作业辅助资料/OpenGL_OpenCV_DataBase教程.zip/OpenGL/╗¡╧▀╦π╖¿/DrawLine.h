#pragma once

#ifndef _DRAW_LINE_

#define	_DRAW_LINE_

#include"SetPixel.h"
#include<cstdlib>
#include<cmath>
void	LineDDA(const Point& start,const Point& end);
void	LineBresenham(const Point& start, const Point& end);

#endif